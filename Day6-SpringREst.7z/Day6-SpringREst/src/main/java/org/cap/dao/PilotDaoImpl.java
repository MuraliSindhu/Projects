package org.cap.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.model.Pilot;
import org.springframework.stereotype.Repository;


@Repository
public class PilotDaoImpl implements IPilotDao{

	private static AtomicInteger pilotId = new AtomicInteger();
	
	private static List<Pilot> pilots=dummyDbPilot();
	
	private static Pilot pilot;
	
	
	public static List<Pilot> dummyDbPilot() {
		List<Pilot> pilots = new ArrayList<Pilot>();
		pilots.add(new Pilot(pilotId.incrementAndGet(), "Tom", "Jerry", new Date(), new Date(), true, 23000));
		pilots.add(new Pilot(pilotId.incrementAndGet(), "Tom", "Jerry", new Date(), new Date(), true, 23000));
		pilots.add(new Pilot(pilotId.incrementAndGet(), "Tom", "Jerry", new Date(), new Date(), true, 23000));
		pilots.add(new Pilot(pilotId.incrementAndGet(), "Tom", "Jerry", new Date(), new Date(), true, 23000));
		return pilots;
	}
	
	
	@Override
	public List<Pilot> getAllPilots() {
		return pilots;
	}


	@Override
	public Pilot findpilot(Integer pilotId) {
		for (Pilot pilot : pilots) {
			if(pilotId==pilot.getPilotId())
			{
				return pilot;
			}
		
		}
		return null; 
	}


	@Override
	public List<Pilot> deletePilot(Integer pilotId) {
		
		boolean flag = false;
		Iterator<Pilot> it = pilots.iterator();
		while(it.hasNext()) {
			Pilot pilot = it.next();
			if(pilot.getPilotId() == pilotId) {
				it.remove();
				flag = true;
				break;
			}
		}
		if(flag) {
		return pilots;
		} else { 
			return null;
		}
	}


	@Override
	public List<Pilot> createPilot(Pilot pilot) {
		pilots.add(pilot);
		return getAllPilots();
	}


	@Override
	public List<Pilot> updateDao(Integer pilotId) {
		if(pilot.getPilotId() == pilotId) {
		pilot.setFirstName(pilot.getFirstName());
		pilot.setLastName(pilot.getLastName());
		pilot.setDateOfBirth(pilot.getDateOfBirth());
		pilot.setDateOfJoining(pilot.getDateOfJoining());
		}
		return getAllPilots();
	}


	
	

}
