package org.cp.demo;

public abstract class SingletonBeam {
	
	private PrototypeBeam prototypeBeam;

	public abstract PrototypeBeam getPrototypeBeam();

	public SingletonBeam() {
		System.out.println("From Singleton Beam");
		
	}
	

}
