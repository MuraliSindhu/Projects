package org.cp.demo;

public class PrototypeBeam {
	
	String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public PrototypeBeam() {
		System.out.println("From Prototype Beam");
	}
	
	
	

}
