package com.wallet;

import static org.junit.Assert.*;

import org.junit.Ignore;
import org.junit.Test;

import com.cg.AppException.BankException;
import com.cg.bean.Customer;
import com.cg.bean.Transaction;
import com.cg.dao.BankDao;
import com.cg.dao.BankDaoImpl;


public class BankDaoTest {
	
	BankDao bdao = new BankDaoImpl();

	@Test
	public void testCreateAccount() {
		Customer c = new Customer();
        c.setName("Sindhu");
        c.setPhone("1234567890");
        c.setAdress("Pune");
        c.setBalance(200000);
        c.setDOB("23-09-1996");
        

        try {
               bdao.createAccount(c);
               double c1 = bdao.showBalance(c.getId());
               assertNotNull(c1);
        } catch (BankException e) {
               // TODO Auto-generated catch block
               System.out.println(e.getMessage());
        }

	}
	
    @Test
    public void testShowBalance() {
           try {
                  double c = bdao.showBalance(1);
                  assertNotNull(c);
                  double c1 = bdao.showBalance(5);
                  assertNotNull(c1);
           } catch (BankException e) {
                  // TODO Auto-generated catch block
                  System.out.println(e.getMessage());
           }
    }
    
    @Test
    public void testDepositPositive() {
           try {
                  assertEquals(80000, bdao.makeDeposit(2, 2000), 0);
           } catch (BankException e) {
                  // TODO Auto-generated catch block
                  e.printStackTrace();
           }
    }
    
    @Test
    public void testWithdrawPositive() {
           try {
                  assertEquals(970000, bdao.doWtihdraw(1, 10000), 20000);
           } catch (BankException e) {
                  // TODO Auto-generated catch block
                  e.printStackTrace();
           }
    }
    
    @Test
    public void testFundTransferPositive() {
           try {
                  assertEquals(82000, bdao.makeDeposit(2, 2000), 0);
                  assertEquals(968000, bdao.doWtihdraw(1, 2000), 0);
           } catch (BankException e) {
                  // TODO Auto-generated catch block
                  e.printStackTrace();
           }
    }
    
    @Test
    public void testPrintTransaction() {
    	try {
           Transaction b = bdao.printTransactions(2);
           assertNotNull(b);
    	} catch (BankException e) {
           // TODO Auto-generated catch block
           e.printStackTrace();
    	}
    }
    




	
	
	

}
