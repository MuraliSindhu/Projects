package com.cg.bean;

public class Transaction {
	
	private String deposit;
	private String withdraw;
	private String fundtransfer;
	public String getDeposit() {
		return deposit;
	}
	public void setDeposit(String deposit) {
		this.deposit = deposit;
	}
	public String getWithdraw() {
		return withdraw;
	}
	public void setWithdraw(String withdraw) {
		this.withdraw = withdraw;
	}
	public String getFundtransfer() {
		return fundtransfer;
	}
	public void setFundtransfer(String fundtransfer) {
		this.fundtransfer = fundtransfer;
	}
	public Transaction(String deposit, String withdraw, String fundtransfer) {
		super();
		this.deposit = deposit;
		this.withdraw = withdraw;
		this.fundtransfer = fundtransfer;
	}
	public Transaction() {
		super();
	}
	@Override
	public String toString() {
		return deposit + withdraw + fundtransfer;
	}
	

}
