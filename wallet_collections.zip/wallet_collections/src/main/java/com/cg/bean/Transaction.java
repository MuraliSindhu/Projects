package com.cg.bean;

public class Transaction {
	
	private int deposit;
	private int withdraw;
	private int fundtransfer;
	
	public int getDeposit() {
		return deposit;
	}
	public void setDeposit(int deposit) {
		this.deposit = deposit;
	}
	public int getWithdraw() {
		return withdraw;
	}
	public void setWithdraw(int withdraw) {
		this.withdraw = withdraw;
	}
	public int getFundtransfer() {
		return fundtransfer;
	}
	public void setFundtransfer(int fundtransfer) {
		this.fundtransfer = fundtransfer;
	}
	
	public Transaction(int deposit, int withdraw, int fundtransfer) {
		super();
		this.deposit = deposit;
		this.withdraw = withdraw;
		this.fundtransfer = fundtransfer;
	}
	
	public Transaction() {
		super();
	}

}
