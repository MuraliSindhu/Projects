package com.cg.dao;

import java.util.HashMap;
import java.util.Optional;

import com.cg.AppException.BankException;
import com.cg.bean.Customer;
import com.cg.bean.Transaction;
import com.cg.db.CustomerDB;
import com.cg.db.TransactionDB;

public class BankDaoImpl implements BankDao{
	
	HashMap<Integer, Customer> bankMap = CustomerDB.getBankMap();
	HashMap<Integer, Transaction> transactionMap = TransactionDB.getTransactionMap();
	
	Customer c;

	@Override
	public int createAccount(Customer cust) throws BankException {
		try {
			if(bankMap.size() == 0) {
				cust.setId(00001);
			} else {
				Optional<Integer> id = bankMap.keySet().stream().max((x,y)->x>y?1:x<y?-1:0);
				int reqid = id.get()+1;
				cust.setId(reqid);
			}
			bankMap.put(cust.getId(), cust);
			Transaction t = new Transaction();
			t.setDeposit(0);
			t.setWithdraw(0);
			t.setFundtransfer(0);
			transactionMap.put(cust.getId(), t);
			return cust.getId();
		} catch (Exception e) {
			throw new BankException(e.getMessage());
		}
		
	}

	@Override
	public double showBalance(int id) throws BankException {
		try {
			if(!bankMap.containsKey(id)) {
				throw new BankException("No bank account with id " + id);
			}
		} catch (Exception e) {
			throw new BankException(e.getMessage());
		}
		return bankMap.get(id).getBalance();
	}

	@Override
	public double makeDeposit(int id, double deposit) throws BankException {
		try {
			if(!bankMap.containsKey(id)) {
				throw new BankException("No bank account with id " + id);
			}
			c = bankMap.get(id);
			double balance = c.getBalance();
			double newBalance = balance + deposit;
			c.setBalance(newBalance);
			Transaction t1 = transactionMap.get(id);
			int num = t1.getDeposit();
			t1.setDeposit(num+1);
			return c.getBalance();
		} catch (Exception e) {
			throw new BankException(e.getMessage());
		}
	}

	@Override
	public double doWtihdraw(int id, double withdraw) throws BankException {
		try {
			if(!bankMap.containsKey(id)) {
				throw new BankException("No bank account with id " + id);
			}
			c = bankMap.get(id);
			double balance = c.getBalance();
			double newBalance = balance - withdraw;
			if(newBalance < 0) {
				throw new BankException("You cannot withdraw more than your balance");
			}
			c.setBalance(newBalance);
			Transaction t1 = transactionMap.get(id);
			int num = t1.getWithdraw();
			t1.setWithdraw(num+1);
			return c.getBalance();
		} catch (Exception e) {
			throw new BankException(e.getMessage());
		}
	}

	@Override
	public double fundTranfer(int id1, int id2, double amount) throws BankException {
		double c1Balance = doWtihdraw(id1, amount);
		double c2Balance = makeDeposit(id2, amount);
		return c1Balance;
	}

	@Override
	public Transaction printTransactions(int id) throws BankException {
		if(!bankMap.containsKey(id)) {
			throw new BankException("No bank account with id " + id);
		}
		Transaction t1 = transactionMap.get(id);
		return t1;
	}
}
