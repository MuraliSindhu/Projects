package com.cg.dao;


import com.cg.AppException.BankException;
import com.cg.bean.Customer;
import com.cg.bean.Transaction;

public interface BankDao {
	
	int createAccount(Customer cust) throws BankException;
	double showBalance(int id) throws BankException;
	double makeDeposit(int id, double deposit) throws BankException;
	double doWtihdraw(int id, double withdraw) throws BankException;
	double fundTranfer(int id1, int id2, double amount) throws BankException;
	Transaction printTransactions(int id) throws BankException;

}
