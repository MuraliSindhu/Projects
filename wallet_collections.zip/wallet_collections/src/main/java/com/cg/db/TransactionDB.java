package com.cg.db;

import java.util.HashMap;

import com.cg.bean.Transaction;

public class TransactionDB {
	
	private static HashMap<Integer, Transaction> transactionMap = new HashMap<Integer, Transaction>();
	
	static {
		transactionMap.put(00001, new Transaction("","",""));
		transactionMap.put(00002, new Transaction("","",""));
		transactionMap.put(00003, new Transaction("","",""));
	}
	
	public static HashMap<Integer, Transaction> getTransactionMap() {
		return transactionMap;
	}
	

}
