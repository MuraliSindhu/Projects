package com.cg.db;

import java.util.HashMap;

import com.cg.bean.Customer;

public class CustomerDB {
	
	private static HashMap<Integer, Customer> BankMap = new HashMap<Integer, Customer>();
	
	static {
		BankMap.put(00001, new Customer(00001, "Ravi", "12-2-1985", "Male", "Chennai", "9876542145", 980000));
		BankMap.put(00002, new Customer(00002, "Phani", "15-8-1963", "Male", "Hyderabad", "7896324563", 78000));
		BankMap.put(00003, new Customer(00003, "Saanvi","14-9-1945", "Female", "Bengaluru", "7845124563", 45));
	}
	
	public static HashMap<Integer, Customer> getBankMap() {
		return BankMap;
	}

}
