package com.cg.wallet.bankdao;

import com.cg.wallet.bankException.BankException;
import com.cg.wallet.bean.BankCustomer;

public interface BankDao {
	
	
	int createAccount(BankCustomer cust) throws BankException;
	boolean validateCustDetails(BankCustomer cust) throws BankException;
	double showBalance(int id) throws BankException;
	double makeDeposit(int id, double deposit) throws BankException;
	double doWithdraw(int id, double withdraw) throws BankException;
	double fundTransfer(int id1, int id2, double amount) throws BankException;

}
