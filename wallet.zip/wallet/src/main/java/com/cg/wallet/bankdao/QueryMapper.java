package com.cg.wallet.bankdao;

public interface QueryMapper {
	
	public static final String INSERT_QUERY="INSERT INTO Wallet VALUES(BankId_sequence.NEXTVAL,?,?,?,?,?,?)";
	public static final String SHOW_BALANCE_QUERY = "SELECT balance from Wallet where id = ?";
	public static final String MAKE_DEPOSIT_QUERY = "UPDATE WALLET SET balance = balance + ? where id = ?"; 
	public static final String DO_WITHDRAW_QUERY = "UPDATE WALLET SET balance = balance - ? where id = ?";
	public static final String BANKID_QUERY_SEQUENCE="SELECT BankId_sequence.CURRVAL FROM DUAL";

}


/******************TABLESCRIPT*******************
CREATE TABLE Wallet(
id NUMBER,
name VARCHAR2(20)
);

CREATE SEQUENCE BankId_sequence;

************************************************/