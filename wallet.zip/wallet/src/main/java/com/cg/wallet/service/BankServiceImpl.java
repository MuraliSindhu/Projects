package com.cg.wallet.service;

import com.cg.wallet.bankException.BankException;
import com.cg.wallet.bankdao.BankDao;
import com.cg.wallet.bankdao.BankDaoImpl;
import com.cg.wallet.bean.BankCustomer;
import com.cg.wallet.bean.TransactionDetails;

public class BankServiceImpl implements BankService{

	BankDao bdao = new BankDaoImpl();

	@Override
	public int createAccount(BankCustomer cust) throws BankException {
		return bdao.createAccount(cust);
	}

	@Override
	public boolean validateCustDetails(BankCustomer cust) throws BankException {
		if (validateName(cust.getName()) && validatePhone(cust.getPhone())) {
			return true;
		}
		return false;
	}
	
	@Override
	public double makeDeposit(int id, double deposit) throws BankException {
		return bdao.makeDeposit(id, deposit);
	}
	
	@Override
	public double showBalance(int id) throws BankException {
		return bdao.showBalance(id);
	}
	
	@Override
	public double doWithdraw(int id, double withdraw) throws BankException {
		return bdao.doWithdraw(id, withdraw);
	}
	
	@Override
	public double fundTransfer(int id1, int id2, double amount) throws BankException {
		if(id1 == id2 || amount == 0) {
			throw new BankException("Invalid fund transfer..");
		}
		return bdao.fundTransfer(id1, id2, amount);
	}
	
	@Override
	public TransactionDetails printTransactions(int id) throws BankException {
		return bdao.printTransactions(id);
	}


	public boolean validatePhone(String phone) throws BankException {
		if(phone.isEmpty() || phone==null)
			throw new BankException("Mobile number is mandatory");
		else {
			if(!phone.matches("\\d{10}")) {
				throw new BankException("Mobile number should contain only 10 digits");
			}
		}
		return true;
	}

	public boolean validateName(String name) throws BankException {
		if(name.isEmpty() || name == null) {
			throw new BankException("Name cannot be empty");
		}
		else {
			if(!name.matches("[A-Z][A-Za-z]{2,}")) {
				throw new BankException
				("Name should start with a Captial letter followed by a minimum of 2 letters");
			}
		}
		return true;
	}
}
