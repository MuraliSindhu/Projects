package com.cg.wallet.bean;

import java.util.Date;

public class TransactionDetails {
	
	private int id;
	private String transType;
	private Date transDate;
	private double amount;
	private int accno;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTransType() {
		return transType;
	}
	public void setTransType(String transType) {
		this.transType = transType;
	}
	public Date getTransDate() {
		return transDate;
	}
	public void setTransDate(Date transDate) {
		this.transDate = transDate;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public int getAccno() {
		return accno;
	}
	public void setAccno(int accno) {
		this.accno = accno;
	}
	public TransactionDetails(int id, String transType, Date transDate, double amount, int accno) {
		super();
		this.id = id;
		this.transType = transType;
		this.transDate = transDate;
		this.amount = amount;
		this.accno = accno;
	}
	public TransactionDetails() {
		super();
	}
	
	public String toString() {
		return "id = " + id + "\ntransType = " + transType + "\ntransDate = " + transDate + "\namount = " + amount + "\nAccount number = " + accno;
	}
}
