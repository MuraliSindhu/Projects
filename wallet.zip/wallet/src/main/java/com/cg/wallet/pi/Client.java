package com.cg.wallet.pi;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.wallet.bankException.BankException;
import com.cg.wallet.bean.BankCustomer;
import com.cg.wallet.service.BankService;
import com.cg.wallet.service.BankServiceImpl;


public class Client {
	
	Scanner scan = new Scanner(System.in);
	BankCustomer c = new BankCustomer();
	//Transaction t = new Transaction();
	BankService bankService = new BankServiceImpl();
	static Logger logger = Logger.getRootLogger();

	
    public static void main( String[] args ) {
    	
		PropertyConfigurator.configure("resources//log4j.properties");
    	Client a = new Client();
    	String option = null;
    	
    	while(true) {
    		System.out.println("==============Online Banking System=============");
        	System.out.println("Choose any of the following");
        	System.out.println("1. Create Account");
        	System.out.println("2. Show balance");
        	System.out.println("3. Deposit");
        	System.out.println("4. Withdraw");
        	System.out.println("5. Fund Transfer");
        	System.out.println("6. Print Transactions");
        	System.out.println("7. Exit");
    		option = a.scan.nextLine();
    		switch(option) {
    		case "1": 
    			a.createAccount();
    			break;
    		case "2": 
    			a.showBalance();
    			break;
    		case "3": 
    			a.makeDeposit();
    			break;
    		case "4": 
    			a.doWithdraw();
    			break;
    		case "5": 
    			a.fundTransfer();
        		break;
       		case "6": 
       			//a.printTansactions();
       			break;
       		case "7":
       			System.exit(0);
       		default:
       			System.out.println("Invalid option. Choose from 1 to 7");
    		}
    	}
    	
    }

	public  void createAccount() {
		System.out.println("Enter your name:");
		c.setName(scan.nextLine());
		System.out.println("Enter your Date of Birth:");
		c.setDOB(scan.nextLine());
		System.out.println("Enter your gender");
		c.setGender(scan.nextLine());
		System.out.println("Provide your Address");
		c.setAdress(scan.nextLine());
		System.out.println("Enter your phone number");
		c.setPhone(scan.nextLine());
		c.setBalance(0);
		boolean result;
		try {
			result = bankService.validateCustDetails(c);
			if(result) {
				int ret = bankService.createAccount(c);
				System.out.println("Bank account created succesfully. Bank account number: " + ret);
				System.out.println(c.toString());
			}
		} catch (BankException e) {
			logger.error("exception occured", e);
			System.out.println("ERROR : "+ e.getMessage());
		}
	}
	
	public void showBalance() {
		
		try {
			System.out.println("Enter bank account number: ");
			int id = Integer.parseInt(scan.nextLine());
			double balance = bankService.showBalance(id);
			System.out.println("Your balance is: " + balance);
		} catch (NumberFormatException e) {
			System.err.println("An error occuered: " + e.getMessage());
		} catch (BankException e) {
			System.err.println("An error occuered: " + e.getMessage());
		}
	}
	
	public void makeDeposit() {
		try {
			System.out.println("Enter bank account number to make deposit");
			int id = Integer.parseInt(scan.nextLine());
			System.out.println("Enter amount to be deposited");
			double deposit = Float.parseFloat(scan.nextLine());
			double balance = bankService.makeDeposit(id, deposit);
			System.out.println("Money deposited into account "+ id+". Your balance is: " + balance);
		} catch (NumberFormatException e) {
			System.err.println("An error occuered: " + e.getMessage());
		} catch (BankException e) {
			System.err.println("An error occuered: " + e.getMessage());
		}
		
	}
	
	public void doWithdraw() {
		
		try {
			System.out.println("Enter bank account number: ");
			int id = Integer.parseInt(scan.nextLine());
			double balance1 = bankService.showBalance(id);
			System.out.println("Your balance is: " + balance1);
			System.out.println("Enter amount to withdraw: ");
			double withdraw = Float.parseFloat(scan.nextLine());
			double balance2 = bankService.doWithdraw(id, withdraw);
			System.out.println("Money withdrawn from account number:" + id + ". Your remaining balance is: " + balance2);
		} catch (NumberFormatException e) {
			System.err.println("An error has occuered.. " + e.getMessage());
		} catch (BankException e) {
			System.err.println("An error has occuered.. " + e.getMessage());
		}
		
	}
	
	public void fundTransfer() {
		
		try {
			System.out.println("Enter your bank account number: ");
			int id1 = Integer.parseInt(scan.nextLine());
			System.out.println("Enter bank account number where the funds to be transferred");
			int id2 = Integer.parseInt(scan.nextLine());
			System.out.println("Enter amount to be transferred: ");
			double amount = Integer.parseInt(scan.nextLine());
			double balance = bankService.fundTransfer(id1, id2, amount);
			System.out.println("Money transferred from account number "+id1+" to account number "+id2+".");
			System.out.println("Remaining balance in your account: " + balance);
		} catch (NumberFormatException e) {
			System.err.println("An error occuered.. " + e.getMessage());
		} catch (BankException e) {
			System.err.println("An error occuered.. " + e.getMessage());
		}
	}
	
	/*public void printTansactions() {
		try {
			System.out.println("Enter your bank account number: ");
			int id = Integer.parseInt(scan.nextLine());
			t = bankService.printTransactions(id);
			System.out.println("No. of deposits: " + t.getDeposit());
			System.out.println("No. of withdrawal: " + t.getWithdraw());
			System.out.println("Total number of Transactions so far: " +(t.getDeposit()+t.getWithdraw()));
		} catch (NumberFormatException e) {
			System.out.println("An error occuered.." +  e.getMessage());
		} catch (BankException e) {
			System.out.println("An error occuered.." +  e.getMessage());
		}
		
	}*/

}
