package com.cg.wallet.pi;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.wallet.service.BankService;
import com.cg.wallet.service.BankServiceImpl;


public class Client {
	
	static Scanner sc = new Scanner(System.in);
	static BankService bankService = null;
	static BankServiceImpl employeeServiceImpl = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) {
		PropertyConfigurator.configure("resources//log4j.properties");
	}

}
