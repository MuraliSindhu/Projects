package com.cg.wallet.test;



import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.cg.wallet.bankException.BankException;
import com.cg.wallet.bankdao.BankDao;
import com.cg.wallet.bankdao.BankDaoImpl;
import com.cg.wallet.bean.BankCustomer;
import com.cg.wallet.bean.TransactionDetails;

public class WalletTest {
	
	BankDao bdao = new BankDaoImpl();
	
	@Test
	public void testCreateAccount() {
		BankCustomer c = new BankCustomer();
        c.setName("Sindhu");
        c.setPhone("1234567890");
        c.setAdress("Pune");
        c.setBalance(200000);
        c.setDOB("23-09-1996");
        

        try {
               bdao.createAccount(c);
               double c1 = bdao.showBalance(c.getId());
               assertNotNull(c1);
        } catch (BankException e) {
               System.out.println(e.getMessage());
        }

	}
	
    @Test
    public void testShowBalance() {
           try {
                  double c = bdao.showBalance(41);
                  assertNotNull(c);
                  double c1 = bdao.showBalance(45);
                  assertNotNull(c1);
           } catch (BankException e) {
                  System.out.println(e.getMessage());
           }
    }
    
    @Test
    public void testDepositPositive() {
           try {
                  assertEquals(7000, bdao.makeDeposit(41, 2000), 0);
           } catch (BankException e) {
                  e.printStackTrace();
           }
    }
    
    @Test
    public void testWithdrawPositive() {
           try {
                  assertEquals(20000, bdao.doWithdraw(42, 1000), 0);
           } catch (BankException e) {
                  e.printStackTrace();
           }
    }
    
    @Test
    public void testFundTransferPositive() {
           try {
                  assertEquals(9000, bdao.makeDeposit(41, 2000), 0);
                  assertEquals(18000, bdao.doWithdraw(41, 2000), 0);
           } catch (BankException e) {
                  e.printStackTrace();
           }
    }
    
    @Test
    public void testPrintTransaction() {
    	try {
           TransactionDetails b = bdao.printTransactions(42);
           assertNotNull(b);
    	} catch (BankException e) {
           e.printStackTrace();
    	}
    }
    
}
