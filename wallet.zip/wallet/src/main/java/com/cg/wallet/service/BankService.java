package com.cg.wallet.service;

import com.cg.wallet.bankException.BankException;
import com.cg.wallet.bean.BankCustomer;
import com.cg.wallet.bean.TransactionDetails;

public interface BankService {
	
	int createAccount(BankCustomer cust) throws BankException;
	boolean validateCustDetails(BankCustomer cust) throws BankException;
	double showBalance(int id) throws BankException;
	double makeDeposit(int id, double deposit) throws BankException;
	double doWithdraw(int id, double withdraw) throws BankException;
	double fundTransfer(int id1, int id2, double amount) throws BankException;
	TransactionDetails printTransactions(int id) throws BankException;

}
