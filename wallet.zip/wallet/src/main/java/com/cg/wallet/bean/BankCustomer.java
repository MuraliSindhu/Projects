package com.cg.wallet.bean;

public class BankCustomer {
	private int id;
	private String name;
	private String DOB;
	private String gender;
	private String adress;
	private String phone;
	private int balance;
	
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public int getBalance() {
		return balance;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDOB() {
		return DOB;
	}
	public void setDOB(String string) {
		DOB = string;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAdress() {
		return adress;
	}
	public void setAdress(String adress) {
		this.adress = adress;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public BankCustomer(int id, String name, String dOB, String gender, String adress, String phone, int balance){
		super();
		this.id = id;
		this.name = name;
		this.DOB = dOB;
	    this.gender = gender;
		this.adress = adress;
		this.phone = phone;
		this.balance = balance;
	}
	public BankCustomer() {
		super();
	}
	
	
	public String toString() {
		return "id = " + id + "\nname = " + name +"\ndob = " + DOB + "\ngender = " + gender + "\naddress = " + adress + "\nphone = "
				 + phone + "\nbalance = " + balance;
	}
	
	

}
