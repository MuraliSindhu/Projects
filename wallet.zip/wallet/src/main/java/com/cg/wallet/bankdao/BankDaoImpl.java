package com.cg.wallet.bankdao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.cg.wallet.bankException.BankException;
import com.cg.wallet.bankutil.DBConnection;
import com.cg.wallet.bean.BankCustomer;

public class BankDaoImpl implements BankDao{
	
	Logger logger=Logger.getRootLogger();
	
	public BankDaoImpl() {
		PropertyConfigurator.configure("resources//log4j.properties");
	}

	@SuppressWarnings("resource")
	@Override
	public int createAccount(BankCustomer cust) throws BankException {
		Connection connection = DBConnection.getInstance().getConnection();
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		int BankId=0;
		int queryResult=0;
		
		try {
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);
			preparedStatement.setString(1,cust.getName());
			queryResult=preparedStatement.executeUpdate();
			preparedStatement = connection.prepareStatement(QueryMapper.BANKID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next()){
				BankId=resultSet.getInt(1);
						
			}
			if(queryResult==0) {
				logger.error("Insertion failed ");
				throw new BankException("Inserting employee details failed ");
			}
			else {
				logger.info("Employee details added successfully:");
				return BankId;
			}
			
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new BankException("Tehnical problem occured. Refer log");
		}
		
		finally {
			try {
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new BankException("Error in closing db connection");	
			}
		}
	}

	@Override
	public boolean validateCustDetails(BankCustomer cust) throws BankException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public double showBalance(int id) throws BankException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double makeDeposit(int id, double deposit) throws BankException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double doWithdraw(int id, double withdraw) throws BankException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double fundTransfer(int id1, int id2, double amount) throws BankException {
		// TODO Auto-generated method stub
		return 0;
	}

}
