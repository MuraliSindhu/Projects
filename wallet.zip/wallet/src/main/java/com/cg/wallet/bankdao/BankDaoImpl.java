package com.cg.wallet.bankdao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.cg.wallet.bankException.BankException;
import com.cg.wallet.bankutil.DBConnection;
import com.cg.wallet.bean.BankCustomer;

public class BankDaoImpl implements BankDao{
	
	Logger logger=Logger.getRootLogger();
	
	public BankDaoImpl() {
		PropertyConfigurator.configure("resources//log4j.properties");
	}

	@SuppressWarnings("resource")
	@Override
	public int createAccount(BankCustomer cust) throws BankException {
		Connection connection = DBConnection.getInstance().getConnection();
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		int BankId=0;
		int queryResult=0;
		
		try {
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);
			preparedStatement.setString(1, cust.getName());
			preparedStatement.setString(2, cust.getDOB());
			preparedStatement.setString(3, cust.getGender());
			preparedStatement.setString(4, cust.getAdress());
			preparedStatement.setString(5, cust.getPhone());
			preparedStatement.setInt(6, cust.getBalance());
			queryResult=preparedStatement.executeUpdate();
			preparedStatement = connection.prepareStatement(QueryMapper.BANKID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next()){
				BankId=resultSet.getInt(1);
			}
			if(queryResult==0) {
				logger.error("Insertion failed ");
				throw new BankException("Inserting bank details failed ");
			}
			else {
				logger.info("Bank Details added successfully:");
				return BankId;
			}
			
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new BankException("Tehnical problem occured. Refer log");
		} finally {
			try {
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new BankException("Error in closing db connection");	
			}
		}
	}


	@Override
	public double showBalance(int id) throws BankException {
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		try {
			preparedStatement=connection.prepareStatement(QueryMapper.SHOW_BALANCE_QUERY);
			preparedStatement.setInt(1, id);
			resultSet= preparedStatement.executeQuery();

			if(resultSet.next()){
				double balance = resultSet.getDouble("balance");
				return balance;
			} else {
				System.out.println("Invalid account number");
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new BankException("Tehnical problem occured. Refer log");	
		} finally {
			try {
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new BankException("Error in closing db connection");	
			}
		}
		return 0;
	}

	@SuppressWarnings("resource")
	@Override
	public double makeDeposit(int id, double deposit) throws BankException {
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		try {
			//to update in database
			preparedStatement=connection.prepareStatement(QueryMapper.MAKE_DEPOSIT_QUERY);
			preparedStatement.setDouble(1, deposit);
			preparedStatement.setInt(2, id);
			resultSet= preparedStatement.executeQuery();
			
			//to return balance on UI
			preparedStatement=connection.prepareStatement(QueryMapper.SHOW_BALANCE_QUERY);
			preparedStatement.setInt(1, id);
			resultSet= preparedStatement.executeQuery();
			double balance = 0;
			if(resultSet.next()){
				balance = resultSet.getDouble("balance");
			} else {
				System.out.println("Invalid account number");
			}
			return balance;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new BankException("Tehnical problem occured. Refer log");	
		} finally {
			try {
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new BankException("Error in closing db connection");	
			}
		}
	}

	@SuppressWarnings("resource")
	@Override
	public double doWithdraw(int id, double withdraw) throws BankException {
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		
		try {
			//to update in database
			preparedStatement=connection.prepareStatement(QueryMapper.DO_WITHDRAW_QUERY);
			preparedStatement.setDouble(1, withdraw);
			preparedStatement.setInt(2, id);
			resultSet= preparedStatement.executeQuery();
			
			//to present in UI
			preparedStatement=connection.prepareStatement(QueryMapper.SHOW_BALANCE_QUERY);
			preparedStatement.setInt(1, id);
			resultSet= preparedStatement.executeQuery();
			double balance = 0;
			if(resultSet.next()){
				balance = resultSet.getDouble("balance");
			} else {
				System.out.println("Invalid account number");
			}
			return balance;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new BankException("Tehnical problem occured. Refer log");	
		} finally {
			try {
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new BankException("Error in closing db connection");	
			}
		}
	}

	@SuppressWarnings("resource")
	@Override
	public double fundTransfer(int id1, int id2, double amount) throws BankException {
		
		Connection connection = DBConnection.getInstance().getConnection();
		PreparedStatement preparedStatement=null;
		ResultSet resultSet = null;
		
		try {
			preparedStatement=connection.prepareStatement(QueryMapper.MAKE_DEPOSIT_QUERY);
			preparedStatement.setDouble(1, amount);
			preparedStatement.setInt(2, id2);
			resultSet = preparedStatement.executeQuery();
			
			preparedStatement=connection.prepareStatement(QueryMapper.DO_WITHDRAW_QUERY);
			preparedStatement.setDouble(1, amount);
			preparedStatement.setInt(2, id1);
			resultSet = preparedStatement.executeQuery();
			
			preparedStatement=connection.prepareStatement(QueryMapper.SHOW_BALANCE_QUERY);
			preparedStatement.setInt(1, id1);
			resultSet = preparedStatement.executeQuery();
			double balance = 0;
			if(resultSet.next()){
				balance = resultSet.getDouble("balance");
			} else {
				System.out.println("Invalid account number");
			}
			return balance;
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new BankException("Tehnical problem occured. Refer log");	
		} finally {
			try {
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new BankException("Error in closing db connection");	
			}
		}
	}

}
