package com.cg.wallet.bankException;

public class BankException extends Exception{

	public BankException() {
		super();
	}

	public BankException(String arg0) {
		super(arg0);
	}

}
