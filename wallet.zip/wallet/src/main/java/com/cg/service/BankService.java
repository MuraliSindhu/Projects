package com.cg.service;


import com.cg.AppException.BankException;
import com.cg.bean.Customer;
import com.cg.bean.Transaction;

public interface BankService {
	
	int createAccount(Customer cust) throws BankException;
	boolean validateCustDetails(Customer cust) throws BankException;
	double showBalance(int id) throws BankException;
	double makeDeposit(int id, double deposit) throws BankException;
	double doWithdraw(int id, double withdraw) throws BankException;
	double fundTransfer(int id1, int id2, double amount) throws BankException;
	Transaction printTransactions(int id) throws BankException;
}
