package org.cap.model;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class MainClass {

	public static void main(String[] args) {
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("jpademo");
		EntityManager em=factory.createEntityManager();
		em.getTransaction().begin();
		Pilot pilot=new Pilot();
		pilot.setPilotId(1);
		
		pilot.setFirstName("max");
		pilot.setLastName("patrik");
		pilot.setDateOfBirth(new Date(22-01-1997));
		pilot.setDateOfJoining(new Date(11-01-2018));
		pilot.setSalary(1234);
		pilot.setIsCertified(true);
		
		em.persist(pilot);
		em.getTransaction().commit();
		System.out.println("one pilot details added to database");
		em.close();
		factory.close();
		
	}

}
