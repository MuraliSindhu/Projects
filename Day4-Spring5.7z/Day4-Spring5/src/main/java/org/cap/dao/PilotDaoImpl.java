package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.cap.model.Pilot;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository("pilotDao")
@Transactional
public class PilotDaoImpl implements PilotDao{
	
	
	@PersistenceContext
	private EntityManager entityManager;
	@Override
	public void savePilot(Pilot pilot) {
		if(pilot.getPilotId()!=0)
			entityManager.merge(pilot);
			else
				entityManager.persist(pilot);
	}
	@Override
	public List<Pilot> getAll() {
		
		List<Pilot> pilots = entityManager.createQuery("from Pilot").getResultList();
		return pilots;
	}
	@Override
	public void delete(Integer pilotId) {
		Pilot pilot= entityManager.find(Pilot.class, pilotId);
		entityManager.remove(pilot);
	}
	@Override
	public Pilot findPilot(Integer ptId) {
		Pilot pilot=entityManager.find(Pilot.class,ptId );
		return pilot;
	}
	@Override
	public void edit(Pilot pilot) {
		if(pilot.getPilotId()!=0)
			entityManager.merge(pilot);
		else
			entityManager.persist(pilot);
	}

}
