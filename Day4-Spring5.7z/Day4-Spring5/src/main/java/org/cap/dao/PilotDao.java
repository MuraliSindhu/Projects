package org.cap.dao;

import java.util.List;

import org.cap.model.Pilot;

public interface PilotDao {
	
	public void savePilot(Pilot pilot);
	public List<Pilot> getAll();
	public void delete(Integer pilotId);
	//public void edit(Integer pilotId);
	public Pilot findPilot(Integer ptId);
	public void edit(Pilot pilot);

}
